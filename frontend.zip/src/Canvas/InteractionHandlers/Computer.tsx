import React from 'react'

const Computer = () => {
  return (
    <div className='absolute top-0 right-1/2 left-1/2 h-20 w-20'>open commputer</div>
  )
}

export default Computer